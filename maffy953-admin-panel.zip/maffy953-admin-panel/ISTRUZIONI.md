# Come attivare il pannello di amministrazione

Ho trasformato il tuo sito in modo che bio, foto delle opere, video delle interviste
ed email di contatto siano lette da un file `content/site.json`, invece che scritte
nel codice HTML. Ho aggiunto un pannello `/admin` (Decap CMS, gratuito e open source)
che ti permette di modificarle da browser, con login sicuro, senza toccare codice.
Ogni modifica salvata dal pannello crea un commit nel tuo repository GitHub, e
GitHub Pages aggiorna il sito da solo in 1-2 minuti.

## File che ti ho preparato

- `index.html` — versione aggiornata del tuo sito, legge i contenuti da `content/site.json`
- `content/site.json` — bio, opere, interviste, email (i tuoi contenuti attuali, già dentro)
- `images/mf-001.jpg` — la tua immagine "Le Frequenze della Vita", estratta ed esportata come file vero
- `admin/index.html` e `admin/config.yml` — il pannello di amministrazione

## Passo 1 — Carica i file sul repository

1. Vai su `github.com/maffy953/maffy953.github.io`
2. Trascina dentro (o carica con "Add file → Upload files") tutti i file che ti ho dato,
   mantenendo le sottocartelle (`content/`, `images/`, `admin/`)
3. Fai commit direttamente sul branch `main`

## Passo 2 — Crea una GitHub OAuth App (serve per il login nel pannello)

1. Vai su **github.com/settings/developers** → **OAuth Apps** → **New OAuth App**
2. Compila così:
   - **Application name**: maffy953 admin
   - **Homepage URL**: `https://maffy953.github.io`
   - **Authorization callback URL**: la userai al passo 3 (te la dà il proxy)
3. Salva e annota **Client ID** e **Client Secret** (li userai al passo 3)

## Passo 3 — Attiva il "ponte" di autenticazione (OAuth proxy)

GitHub Pages non gestisce da solo il login OAuth, quindi serve un piccolo servizio
gratuito che fa da ponte. Il più semplice, gratuito e già pronto è questo:

1. Vai su **github.com/vencax/netlify-cms-github-oauth-provider**
2. Clicca il pulsante "Deploy to Vercel" (o Heroku, se preferisci) nel loro README
3. Durante il deploy ti chiederà `OAUTH_CLIENT_ID` e `OAUTH_CLIENT_SECRET`:
   incolla i valori ottenuti al Passo 2
4. Al termine del deploy otterrai un indirizzo tipo `https://tuo-nome.vercel.app`
5. Torna nella tua GitHub OAuth App (Passo 2) e imposta la **Authorization callback URL**
   su `https://tuo-nome.vercel.app/callback`
6. Apri `admin/config.yml` nel tuo repository e sostituisci
   `https://SOSTITUISCI-CON-IL-TUO-OAUTH-PROXY` con `https://tuo-nome.vercel.app`

## Passo 4 — Email di contatto

Apri `content/site.json` (o più semplicemente il pannello admin una volta attivo)
e sostituisci `INSERISCI-EMAIL` con la tua vera email di contatto.

## Passo 5 — Usa il pannello

Vai su **maffy953.github.io/admin** → accedi con GitHub → modifica bio, opere,
interviste, email → **Publish**. Il sito si aggiorna da solo in 1-2 minuti.

## Nota sui commenti

I commenti nella sezione "Commenti" restano come sono ora: visibili solo nel tuo
browser, non salvati in modo permanente (si perdono ricaricando la pagina). Se vuoi
commenti veri e persistenti, un'ottima opzione gratuita è **Giscus**, che usa le
Discussioni di GitHub — fammi sapere se vuoi che te lo integri.
